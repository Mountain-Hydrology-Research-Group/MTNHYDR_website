Description of North Cascades Matlab Files

.m Files

add_ibutton_serialdate.m	
This program is used to add the long serial date to the 11th row			of data already imported using get_ibutton

EOF_general.m	
This program works on any dataset.  It is to be subsequently used by EOF_plot.  Bofore running this program on the North Cascades data, first run get_Tmax_for_eof (or min or mean) to obtain a properly formated temperature data file.

EOF_plot.m	
After running EOF_general, use this program to plot all the EOF results.

get_ibutton.m	
Reads ibutton text formatted data into matlab

get_ibutton_interp.m	
This program can be used to obtain a temperature data file, which reports the temperature every hour on the hour.  It will interpolate the temperature data in order to do this.  It should be used after importing ibutton data using get_ibuttons.m

getT_LapseRate.m 
This program uses Tair_mean.mat to create a matrix where the first row(1,:) is the date and the second row(2,:) is the daily lapse rate

get_Tmax.m (or min/mean)
Creates a matrix where the first row is the date
and the subsequent rows contain the daily max/min/mean temperature for each
temperature sensor.

get_Tmax_for_eof.m (or min/mean)	
Creates two matrices: one which contains only the date and the second one which consists of rows of sensor data and columns of daily mean temps.  These matricies are to be used by EOF_general and EOF_plot.

julday.m	
This program is called by numerous other programs in order to format dates in the julian date format.

Lapse_Rate_Daily.m
calculates and plots the lapse rate for a particular day		
Lapse_Rate_Daily_NaN.m	calculates and plots the lapse rate for a particular day	and Works on data sets containing Nan values.

Lapse_Rate_Seasonal.m	
calculates and creates 4 different sub-plots of the laspe rates for each season

Lapse_Rate_Total.m	
Calculates and plots the lapse rate across an entire data set

max_daily_plot.m (or min/mean)	
creates a plot with multiple subplots.  Each sub-plot shows the daily max temperature over the length of the data set
for a particular sensor.

mean_single_daily_plot() (or min/max)  
these are simple functions for plotting the daily min/mean/max temperature across a data set.  They are later called in min_max_mean_plot.m and min_max_mean_together.m 

min_max_mean_plot.m	
Creates one plot with 3 different sub-plots.  The sub-plots depict the min, max, and mean daily temperatures for a particular sensor over the data set.  This method calls the methods ean_single_daily_plot() / min/max.

min_max_mean_together.m	
Creates a single plot containing the daily min, max, and mean for a particular sensor across the length of the data.  This method calls the methods mean_single_daily_plot() / min/max.  This method can create as many plots as you desire all at the same time, though it could get confusing if you plot more than 4 or so.

naneof_br2.m	
This method is called by EOF_general.m

nanmean.m	
This is a method I downloaded from matlab's site.  It is called by some of my methods and allows for the calculation of mean on data sets containing Nan values

raw_plot_many.m	
Plots multiple sensor data on a single plot when passed sensor data and a title. Must be adapted depending on how many sensors you are trying to plot.

rawdata_plot.m	
Plots data from a single sensor when passed the sensor name and a title.  


.mat files

date_i_button_data.mat
Contains raw ibutton data that has been formatted using get_ibutton.m

date_i_button_data_ends_trimmed.mat
Contains raw ibutton data that has been formatted using get_ibutton.m and then trimmed, so that it only includes dates when the ibuttons were actually deployed

date_i_button_data_ends_trimmed_bad_data_removed.mat
Contains raw ibutton data that has been formatted using get_ibutton.m and then trimmed, so that it only includes dates when the ibuttons were actually deployed.  Lastly, NaN values have been inserted for bad temperature data.  In the N.Cascades data set, this only occurs in sensor #s 1, 11, 35

date_i_button_data_ends_trimmed_bad_data_removed-999.mat
This is the same as date_i_button_data_ends_trimmed_bad_data_removed.mat except that instead of using NaN to replace bad temperature data, -999 was used.

eof_max_all.mat (or mean/min)
The files that resulted after running EOF_general.m on Tair_max (or mean/min).  EOF_plot.m can be run using these.

IDfiles.mat
IDfile and ID_file are the same (just transposed).  It contains the sensor number, latitude, longitude, and elevation

NCibutton_before_csv
Matrix containing yr,month,day, and hour followed by interpolated temperature data for each sensor (1:30, 33:45)

Tfiles.mat
Contains files generated using get_Tmax.m (or min/mean) for soil sensors, air sensors, and both soil and air sensors.  Also contains the file generated from getT_LapseRate.m 
