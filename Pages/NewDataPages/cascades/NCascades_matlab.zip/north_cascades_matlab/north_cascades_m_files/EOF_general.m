%T_eof_general.m
%1/09/2007,
% This is designed to be used by anyone with a matrix of temperature data
%this example uses Nick Pepin's data from the Pyrenees.

% First, load a matrix with rows of temperature timeseries at different
% locations  (if there are columns instead of rows, you do/do not need to
% use the transpose of the matrix
%EXAMPLE:  load('Pyrenees2.mat')
%this mat file was created by get_pyreneesT.m

% select stations and times with some data 

Tmeanall=Tair_maxNaN'; %This is the variable name of the matrix of temperature data
bad=find(Tmeanall<-99); %this filters for bad data
Tmeanall(bad)=NaN; %this labels bad data as not a number, so it isn't analyzed
station_num_cutoff=16; %this is the minimum number of stations that must have 
 %good data at a given time to run the analysis
time_cutoff=245; %this is the minimum length of record that a station must have to be analyzed
id_t = find(sum(~isnan(Tmeanall'))>station_num_cutoff); % good times
id_z = find(sum(~isnan(Tmeanall(id_t,:)))>time_cutoff); %this yields 27 "decent stations"
  %note that 24 are marked "complete"  good stations 600

Ta = Tmeanall(id_t,id_z); % Restrict your matrix to only examine times and sites when sufficient data are available

% remove the mean over the whole time period at each station
Tan = Ta-repmat(nanmean(Ta),size(Ta,1),1);

% Calculate the regional mean through time
Tref2=nanmean(Tan,2);

%now, remove the region mean fluctuations
Tan2=Tan-Tref2*ones(1,length(id_z));


% determine the size of the original matrix
[M,N ] =size(Tmeanall);

% pad with zeros to get matrix of same dimensions as original matrix
spatial_modes = zeros(N)*nan;
temporal_modes = zeros(M)*nan;
tic
 [B,vars,amps]=naneof_br2(Tan2);
 toc
 NM = min(size(amps));
 % This calcuates the mean power of the fluctuations
 av = sqrt(mean(amps.^2));

 % Below normalizes the spatial mode to an overall mean variance of 1 and 
 % puts that variance into the temporal modes, which contain the
 % eigenvalues
spatial_modes(id_z,1:NM) = amps(:,1:NM)./repmat(av(1:NM),size(amps,1),1); 
temporal_modes(id_t,1:NM) = B(:,1:NM).*repmat(av(1:NM),size(B,1),1); 
variances = vars;

%SVD    Singular value decomposition.
%   [U,S,V] = SVD(X) produces a diagonal matrix S, of the same 
%   dimension as X and with nonnegative diagonal elements in
%   decreasing order, and unitary matrices U and V so that
%   X = U*S*V'.
%
%   S = SVD(X) returns a vector containing the singular values.
%
%   [U,S,V] = SVD(X,0) produces the "economy size"
%   decomposition. If X is m-by-n with m > n, then only the
%   first n columns of U are computed and S is n-by-n.
%   For m <= n, SVD(X,0) is equivalent to SVD(X).
%
%   [U,S,V] = SVD(X,'econ') also produces the "economy size"
%   decomposition. If X is m-by-n with m >= n, then it is
%   equivalent to SVD(X,0). For m < n, only the first m columns 
%   of V are computed and S is m-by-m.
%
%   See also SVDS, GSVD.

%   Copyright 1984-2005 The MathWorks, Inc.
%   $Revision: 5.10.4.5 $  $Date: 2005/06/21 19:36:06 $
%   Built-in function.

clear B M N NM Ta Tan Tan2 Tmeanall Tref2 amps ans av bad id_t id_z time_cutoff station_num_cutoff vars
