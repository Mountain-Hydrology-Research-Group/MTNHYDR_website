%plot_ibut_eof1m
%first run EOF_general.m
%make sure to change figure labels (for spatial and temporal)
%well, that isnt too necessary, just don't confuse yourself

sensors = Tair_maxNaN %change this to the file name containing the data you are running the analysis on

%input the latitude and longitude for each sensor, in the same 
%order as was used in the file above (sensors)
lat2 = [48.677 48.66128 48.6637 48.66544 48.6696 48.6678 48.50595 48.50891 48.50817 48.50513 48.49985 48.72850 48.70633 48.66721 48.58819 48.519 48.57941 48.58695 48.59751 48.56206 48.51798];
lon2 = [121.0816 121.04389 121.04859 121.05565 121.05745 121.0675 120.75573 120.74480 120.76388 120.76894 120.76066 121.05650 120.91788 120.87299 120.80276 120.67504 120.63326 120.48913 120.45058 120.63631 120.73533];


%Here I added some extra points that form the road through the
%North Cascades.  This just helps me which points correspond 
%to which locations in the park.
hwy_lat = [48.487994 48.494799 48.505006 48.527123 48.581564 48.617290 48.653017 48.668328 48.685341 48.698951 48.707458 48.709159 48.715964 48.726172 48.721068 48.721068 48.717665 48.710860 48.705756 48.704055 48.704055 48.707458 48.698951 48.697250 48.664926 48.651316 48.638313 48.593473 48.571356 48.562850 48.545837 48.537331 48.505006 48.510405 48.526394 48.573057 48.585018 48.590348 48.595174 48.601007 48.579862];
hwy_long = [121.613316 121.529954 121.484019 121.436384 121.398956 121.353021 121.295178 121.269659 121.232231 121.198206 121.174388 121.121649 121.072312 121.034884 121.022975 121.019572 121.009365 120.983846 120.975339 120.965132 120.937911 120.920899 120.902185 120.898782 120.869860 120.856250 120.854896 120.801810 120.783096 120.774589 120.762680 120.755875 120.720149 120.711 120.663035 120.633384 120.615069 120.604410 120.589151 120.513809 120.396907];

%figure('Name', 'Hourly Spatial', 'NumberTitle','off');
figure('Name', 'Maximum Spatial', 'NumberTitle','off');
%figure('Name', 'Mean Spatial', 'NumberTitle','off');
%figure('Name', 'Minimum Spatial', 'NumberTitle','off');

for j=1:4
    test=spatial_modes(:,j);
    subplot(2,2,j)
    plot(-hwy_long,hwy_lat,'g-')
    hold on
    
    for i=1:length(sensors(:,1))  
        if test(i)>0
            plot(-lon2(i),lat2(i),'bo','markersize',test(i)*15)
            hold on
        elseif test(i)<0
            plot(-lon2(i),lat2(i),'mo','markersize',-test(i)*15)
            hold on
        end 
    end

    
    %axis ([-105.65 -105.5 40.03 40.07])
 xlabel('longitude W')
 ylabel('latitude N')
 eval(['title('' EOF ' num2str(j) ', R^2=' num2str(round(variances(j)*10)/10) ''');'])
end
 
clear test i j

%figure('Name', 'Hourly Temporal', 'NumberTitle','off');
figure('Name', 'Maximum Temporal', 'NumberTitle','off');
%figure('Name', 'Mean Temporal', 'NumberTitle','off');
%figure('Name', 'Minimum Temporal', 'NumberTitle','off');

 for j=1:4
     test=temporal_modes(:,j);
     subplot(4,1,j)
     plot(T_Time,-test)
     axis auto
     eval(['title('' EOF ' num2str(j) ', R^2=' num2str(round(variances(j)*10)/10) ''');'])
     hold on
     plot(T_Time,0,'k')

 end
 
 display('Done')
 
 clear test i j lat2 lon2 hwy_lat hwy_long
 