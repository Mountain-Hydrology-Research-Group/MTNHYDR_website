%Lapse_Rate_Daily.m is used to calculate and plot the lapse rate
%for a particular day.
%This program uses the file Tair_mean which can be found in Tfiles.mat (or
%created using get_Tmean)

%The data in Tair_mean is as follows (numbers representing ibutton data):
%[year-date; 1; 3; 5; 7; 9; 11; 13; 15; 17;
%19; 21; 23; 25; 27; 29; 33; 35; 37; 
%39; 41; 43]

%List the elevation for each ibutton sensor in the same order as listed for
%d:
e = [364 1073 970 745 703 721 1729 1672 1843 2024 2121 663 593 797 1133 1640 1167 697 695 1222 1516];

for j = 322   %Set j = column number for the day you want to plot
    num_sensors = (length(Tair_mean(:,1))) - 1;  %Since row 1 contains the date, we don't want to inclue it
    for i = 1:num_sensors 
       t(i) = Tair_mean(i + 1,j);
    end

    p = polyfit(t,e,1);
    lapse_rate(j) = roundn((1000/(p(1))),-1);
    f = polyval(p,t);
    plot(t(1,1:6),e(1,1:6),'o',t(1,7:11),e(1,7:11),'x',t(1,12:15),e(1,12:15),'square',t(1,16:21),e(1,16:21),'^',t,f,'-')
    hold on
    ylabel('Elevation in meters')
    xlabel(['Average Temperature in ' setstr(176) 'C'])
    legend('Thunder Creek','Maple Pass','West Slope Campgrounds', 'East Slope Campgounds',['Lapse Rate = ' num2str(roundn((1000/(p(1))),-1)), setstr(176) 'C per km'],'location','so')
    title(['Daily Lapse Rate for ' num2str(Tair_mean(1,j))])
    hold off
end

display ('Done')
clear lapse_rate num_sensors e  p
