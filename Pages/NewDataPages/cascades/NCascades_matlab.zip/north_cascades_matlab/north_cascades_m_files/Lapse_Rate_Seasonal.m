%Lapse_Rate_Seasonal.m calculates the laspe rate based on calculating   
%the average temperature for each season.  
%This program is to be used on data read into matlab with
%the program get_ibutton.m
%Created by Natalie Low 08/14/08

%Enter the ibutton numbers:
d = [ 3 5 7 9 13 15 17 19 21 23 25 27 29 33 41 43]; 
%Enter the elevation for each ibutton sensor in the same order as listed
%for d:
e = [ 1073 970 745 703 1729 1672 1843 2024 2121 663 593 797 1133 1640 1222 1516]; 
season1 = [datenum('12/22/07', 'mm/dd/yy')]; %enter the dates for the first day of winter
season2 = [datenum('03/20/08', 'mm/dd/yy')];  %enter the dates for the first day of spring
season3 = [datenum('06/21/07', 'mm/dd/yy'),datenum('06/20/08', 'mm/dd/yy')];  %enter the dates for the first day of summer
season4 = [datenum('09/23/07', 'mm/dd/yy'),datenum('09/22/08', 'mm/dd/yy')];  %enter the dates for the first day of autumn

for j = 1:4  %1 = winter; 2 = spring; 3 = summer; 4 = autumn
    for i = 1:length(d)  
        file = eval([ 'ibut' num2str(d(i))]);  %Enter the prefix for your ibutton name in front of str2num(d(i))

        if j<=3
            start = eval(['season' num2str(j);]);
            finish = eval(['season' num2str(j + 1);]);
        else
            start = eval(['season' num2str(j);]);
            finish = eval(['season' num2str(j - 3);]);
        end

        if length(start) <= length(finish)
            l = length(start);
        else
            l = length(finish);
        end

        for k = 1:l
            if length(start) < length(finish)
            [row1, col1] = find(file(9,:) == start(k), 1, 'first');
            [row2, col2] = find(file(9,:) == finish(k + 1) - 1, 1, 'last');
            else    
            [row1, col1] = find(file(9,:) == start(k), 1, 'first');
            [row2, col2] = find(file(9,:) == finish(k) - 1, 1, 'last');
            end
            if isempty(col1)
               col1 = 1;
            end
            if isempty(col2)
               col2 = length(file);
            end
            t(k) = nanmean(file(8,col1:col2));
        end
        tt(i) = mean(t);
      
    end
        [poly,S] = polyfit(tt,e,1);
        p(j) = poly(1);
        b(j) = poly(2);
        f = polyval(poly,tt);
        subplot(4,1,j)
        plot(tt(1,1:4),e(1,1:4),'o',tt(1,5:9),e(1,5:9),'x',tt(1,10:13),e(1,10:13),'square',tt(1,14:16),e(1,14:16),'^',tt,f,'-')
        ylabel('Elevation(m)','fontsize',8)
        xlabel(['Average Temperature in ' setstr(176) 'C'],'fontsize',8)
    if j == 1
            seasLR = ['Winter Lapse Rate = ' num2str(roundn((1000/(p(1))),-1)), setstr(176) 'C per km']
        elseif  j == 2
            seasLR = ['Spring Lapse Rate = ' num2str(roundn((1000/(p(2))),-1)), setstr(176) 'C per km']
        elseif j == 3
            seasLR = ['Summer Lapse Rate = ' num2str(roundn((1000/(p(3))),-1)), setstr(176) 'C per km'] 
        else
            seasLR = ['Autumn Lapse Rate = ' num2str(roundn((1000/(p(4))),-1)), setstr(176) 'C per km']
     end
        leg = legend('Thunder Creek','Maple Pass','West Slope Campgrounds', 'East Slope Campgounds',seasLR,'location', 'eo');
        set(leg,'FontSize',7)
    
end


display(['Winter Lapse Rate = ' num2str(roundn((1000/(p(1))),-1)), setstr(176) 'C per km'])
display(['Spring Lapse Rate = ' num2str(roundn((1000/(p(2))),-1)), setstr(176) 'C per km'])
display(['Summer Lapse Rate = ' num2str(roundn((1000/(p(3))),-1)), setstr(176) 'C per km'])
display(['Autumn Lapse Rate = ' num2str(roundn((1000/(p(4))),-1)), setstr(176) 'C per km'])

display('Done')
clear S j i k b l seasLR leg col1 col2 d e f file finish p poly row1 row2 season1 season2 season3 season4 start t tt