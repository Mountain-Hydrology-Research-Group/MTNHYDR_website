%This program calculates and plots the laspe rate for an entire data set.
%This program is to be used on data read into matlab with
%the program get_ibutton.m
%Created and last edited by Natalie Low 08/21/08

%Enter the ibutton sensor number:
d = [1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 33 35 37 39 41 43]; %[ 3 5 7 9 13 15 17 19 21 23 25 27 29 33 37 39 41 43]; %[1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 33 35 37 39 41 43];  
%Enter the elevation for each sensor in the same order as listed for d:
elev = [364 1073 970 745 703 721 1729 1672 1843 2024 2121 663 593 797 1133 1640 1167 697 695 1222 1516];  %[1073 970 745 703 1729 1672 1843 2024 2121 663 593 797 1133 1640 697 695 1222 1516];  %[364 1073 970 745 703 721 1729 1672 1843 2024 2121 663 593 797 1133 1640 1167 697 695 1222 1516]; 

for i = 1:length(d)  
    file = eval([ 'ibut' num2str(d(i))]);  %Enter the prefix for your ibutton name in front of str2num(d(i))
    t(i) = nanmean(file(8,:)); 
end
    
p = polyfit(t,elev,1);
display(['Total Lapse Rate = ' num2str(roundn((1000/(p(1))),-1)), setstr(176) 'C per km'])

f = polyval(p,t);
%plot(t(1,1:4),elev(1,1:4),'o',t(1,5:9),elev(1,5:9),'x',t(1,10:13),elev(1,10:13),'square',t(1,14:18),elev(1,14:18),'^',t,f,'-')
plot(t(1,1:6),elev(1,1:6),'o',t(1,7:11),elev(1,7:11),'x',t(1,12:15),elev(1,12:15),'square',t(1,16:21),elev(1,16:21),'^',t,f,'-')
hold on
ylabel('Elevation in meters')
xlabel(['Average Temperature in ' setstr(176) 'C'])
legend('Thunder Creek','Maple Pass','West Slope Campgrounds', 'East Slope Campgounds',['Total Lapse Rate = ' num2str(roundn((1000/(p(1))),-1)), setstr(176) 'C per km'],'location','ne')
title('Annual Lapse Rate for 2007-2008')
hold off

display('Done')
clear t p m d elev f file i 