%This program is used to add the long serial date to the 11th row
%of data already imported using get_ibutton

d = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 33 34 35 36 37 38 39 40 41 42 43 44 45]; %[5 17 18 19 20 23 24 39 40 41 68 69 70]; %[1 2 32 34 37 39 40 50 7 9 10 203 33 36 38 4 5 60 8 333];

for i=1:length(d)
   display(['Processing file ' num2str(i) '/' num2str(length(d)) '...']); % Display progress
   file = eval(['ibut' num2str(d(i));]);
   
   for j = 1:length(file)
       date = [num2str(file(2,j)) '/' num2str(file(3,j)) '/' num2str(file(1,j)) ' ' num2str(file(4,j))];
       serialdate(j) = datenum(date, 'mm/dd/yyyy HH');
   end
   
   eval(['ibut' num2str(d(i)) '(11,:) =' 'serialdate;']);
   clear serialdate date file
end

display('Done')
clear i j d 