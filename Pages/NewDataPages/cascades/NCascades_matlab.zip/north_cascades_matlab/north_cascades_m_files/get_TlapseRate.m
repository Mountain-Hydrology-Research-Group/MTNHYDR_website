%This program is designed to create a matrix where the first row(1,:) 
%is the date and the second row(2,:) is the daily lapse rate

%This program uses the file Tair_mean which can be found in Tfiles.mat 
%(or created using get_Tmean)

%The data in Tair_mean is as follows (numbers representing ibutton data):
%[year-date; 1; 3; 5; 7; 9; 11; 13; 15; 17;
%19; 21; 23; 25; 27; 29; 33; 35; 37; 
%39; 41; 43]



e = [364 1073 970 745 703 721 1729 1672 1843 2024 2121 663 593 797 1133 1640 1167 697 695 1222 1516]; %List the elevation for each ibutton sensor in the same order as listed for d

for j = 1:length(Tair_mean(1,:))
    num_sensors = (length(Tair_mean(:,1))) - 1;  %Since row 1 contains the date, we don't want to inclue it
    for i = 1:num_sensors  
       t(i) = Tair_mean(i + 1,j);
    end

    p = polyfit(t,e,1);  %use matlab's polyfit method to fit a line to the data
    lapse_rate(j) = roundn((1000/(p(1))),-1);  %calculate the daily lapse rate baed on the slope of the line found by polyfit
end

temp(1,:) = Tair_mean(1,:);
temp(2,:) = lapse_rate;

eval([ 'T_LapseRate' '=temp(1:2,:);'])

display ('Done')
clear lapse_rate num_sensors e t p
