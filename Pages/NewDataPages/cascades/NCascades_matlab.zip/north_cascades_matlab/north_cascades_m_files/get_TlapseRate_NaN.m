%This program differs from get_TlapseRate in that it allows NaN values
%It is designed to create a matrix where the first row(1,:) 
%is the date and the second row(2,:) is the daily lapse rate

%This program uses the file Tair_mean which can be found in Tfiles.mat 
%(or created using get_Tmean)

%The data in Tair_mean is as follows (numbers representing ibutton data):
%[year-date; 1; 3; 5; 7; 9; 11; 13; 15; 17;
%19; 21; 23; 25; 27; 29; 33; 35; 37; 
%39; 41; 43]


%List the elevation for each ibutton sensor in the same order as listed for d
e = [364 1073 970 745 703 721 1729 1672 1843 2024 2121 663 593 797 1133 1640 1167 697 695 1222 1516]; 

for j = 1:length(Tair_mean(1,:))
    num_sensors = (length(Tair_mean(:,1))) - 1;  %Since row 1 contains the date, we don't want to inclue it
    for i = 1:num_sensors  
       t(i) = Tair_mean(i + 1,j);
    end

    new_num_sensors = length(find(~isnan(t)));

    if num_sensors ~= new_num_sensors
        [nan_row, nan_col] = find(isnan(t));
        num_nan = length(nan_col)
        l = 1;
        k = 1;
            for q = 1:new_num_sensors
                col  = nan_col(1,l);
                if k ~= col
                        tt(q) = t(1,k);
                        ee(q) = e(1,k);
                elseif k == col
                    tt(q) = t(1,k + 1);
                    ee(q) = e(1,k + 1);
                    k = k + 1;
                    if l < num_nan
                    l = l + 1;
                    end
                end
                k = k + 1;
            end
    p = polyfit(tt,ee,1);
    lapse_rate(j) = roundn((1000/(p(1))),-1);
else
   p = polyfit(t,e,1);  %use matlab's polyfit method to fit a line to the data
   lapse_rate(j) = roundn((1000/(p(1))),-1);  %calculate the daily lapse rate baed on the slope of the line found by polyfit
end
end

temp(1,:) = Tair_mean(1,1:j);
temp(2,:) = lapse_rate;

eval([ 'T_LapseRate_NaN' '=temp(1:2,:);'])

display ('Done')
clear j lapse_rate num_sensors p i e temp col k tt ee l nan_col nan_row new_num_sensors num_nan q t
