%After reading ibutton data in using the method get_ibutton.m, this method
%can be run.  The output is both a matrix containing the date and 
%a corresponding temperature matrix formated for EOF_general.m.
%The temperature matrix consists of rows of sensor data and 
%columns of daily mean temps.

%Created by Natalie Low.

%Enter the ibutton numbers you want included in the table:
p = [1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 33 35 37 39 41 43];% [1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 33 35 37 39 41 43][2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 34 36 38 40 42 44] [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 33 34 35 36 37 38 39 40 41 42 43 44];   %

%First Determine the dates for which all sensors have data
for i = 1
    file = eval(['ibut' num2str(p(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    T_firstday = file(9,1);
    T_lastday = file(9,end);
end

clear i

for i=1:length(p)
    
    file = eval(['ibut' num2str(p(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    firstday = file(9,1);
    lastday = file(9,end);
    
    if firstday >= T_firstday
        T_firstday = firstday;
    end
    
    if lastday <= T_lastday
        T_lastday = lastday;
    end
end

clear firstday lastday i

tot_days = T_lastday - T_firstday + 1;  %tells you the total number of days in the file

%Next find which sensors have NaN values and eliminate these
count = 0;

%for i = 1:length(p)
    %file = eval(['ibut' num2str(p(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    %nans = find(isnan(file(8,:)));
    %if isempty(nans)   %create a new p matrix that puts 0 in for sensors that have nans
       % p2(i) = p(1,i)
       % count = count + 1
    %else
     %   p2(i) = 0;
    %end
%end

%clear i

%k = 1;
%for j = 1:count
    %file = eval(['ibut' num2str(p(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    %nans = find(isnan(file(8,:)));
    %if isempty(nans)
        %p2(j) = p(1,k)
        %k = k + 1;
    %else
       % k = k + 1;
    %end
%end
%clear i  j k

%Now find the daily mean for each sensor that has valid data
for i=1:length(p)
    
    file = eval(['ibut' num2str(p(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    day = T_firstday;
    
    [row,f_col] = find(file(9,:) == T_firstday, 1, 'first');
    [row,l_col] = find(file(9,:) == T_lastday, 1, 'last');
    tot_columns = l_col - f_col + 1;
    
    y = 0;
    x = f_col;

    for j = 1:tot_columns
        if j == x
            for k = 1:tot_days
                if day <= T_lastday
                    
                    freq = find(file(9,:)==day);
                    num_freq = length(freq);
                    y = x - 1 + num_freq;

                    m(k) = nanmean(file(8,x:y));
                    jd(k) = mean(file(10,x:y));
                    d(k) = day;
                    
                    day = day + 1;
                    x = y + 1;
                end  
            end    
        end
    end

    temp(i,:) = m;  %Should read "temp(i + 1,:) = m" if you want date as first row, otherwise "temp(i,:) = m"
end
eval([ 'Tair_meanNaN' '=temp(1:i,:);']) %Should read "temp(1:i + 1,:)" if you want date as first row (and move this line after date for-loop), otherwise "temp(1:i,:)"
clear j k temp
    
yr = str2num(datestr(d, 'yyyy'));

for j = 1:tot_days
    if yr(j,1)==2008    %2008 was a leap yr. if no leap yr-- comment out
        jyr_dy(j) = yr(j,1) + jd(1,j)/366;
    else 
        jyr_dy(j) = yr(j,1) + jd(1,j)/365;
    end
end

temp(1,:) = jyr_dy;
eval([ 'T_Time' '=temp(1,:);']) %Comment out this line if you want one file with time as first row and means as subsequent rows

clear temp T_firstday T_lastday f_col l_col row j d file jd jyr_dy yr m i tot_days lastday firstday tot_columns day freq num_freq x y   


clear file p l
display('Done.') 