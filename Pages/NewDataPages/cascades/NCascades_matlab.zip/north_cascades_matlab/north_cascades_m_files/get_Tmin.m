%After reading ibutton data in using the method get_ibutton.m, this method
%can be used to create a matrix where the first row is the date
%and the subsequent rows contain the daily min temperature for each
%temperature sensor.

%Created by Natalie Low.

% Enter the ibutton numbers you want included in the table:
p = [1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 33 35 37 39 41 43];% [1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 33 35 37 39 41 43][2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 34 36 38 40 42 44] [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 33 34 35 36 37 38 39 40 41 42 43 44];   %

for i = 1
    file = eval(['ibut' num2str(p(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    T_firstday = file(9,1);
    T_lastday = file(9,end);
end

clear i

for i=1:length(p)
    
    file = eval(['ibut' num2str(p(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    firstday = file(9,1);
    lastday = file(9,end);
    
    if firstday >= T_firstday
        T_firstday = firstday;
    end
    
    if lastday <= T_lastday
        T_lastday = lastday;
    end
end

clear firstday lastday i

tot_days = T_lastday - T_firstday + 1;  %tells you the total number of days in the file


for i=1:length(p)
    
    file = eval(['ibut' num2str(p(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    %lastday = file(9,end);%this finds the last day in the file (serial date formatted)
    %firstday = file(9,1);  %this finds the first day in the file (serial date formatted)

    %tot_columns = length(file(9,:));
    
    day = T_firstday;
    
    [row,f_col] = find(file(9,:) == T_firstday, 1, 'first');
    [row,l_col] = find(file(9,:) == T_lastday, 1, 'last');
    tot_columns = l_col - f_col + 1;
    
    y = 0;
    x = f_col;

    for j = 1:tot_columns
        if j == x
            for k = 1:tot_days
                if day <= T_lastday
                    
                    freq = find(file(9,:)==day);
                    num_freq = length(freq);
                    y = x - 1 + num_freq;

                    m(k) = nanmin(file(8,x:y));
                    jd(k) = mean(file(10,x:y));
                    d(k) = day;
                    
                    day = day + 1;
                    x = y + 1;
                end  
            end    
        end
    end

    temp(i + 1,:) = m;
end

clear j k
    
yr = str2num(datestr(d, 'yyyy'));

for j = 1:tot_days
    if yr(j,1)==2008    %2008 was a leap yr. if no leap yr-- comment out
        jyr_dy(j) = yr(j,1) + jd(1,j)/366;
    else 
        jyr_dy(j) = yr(j,1) + jd(1,j)/365;
    end
end

temp(1,:) = jyr_dy;
eval([ 'Tair_min' '=temp(1:i+1,:);'])

clear temp T_firstday T_lastday f_col l_col row j d file jd jyr_dy yr m i tot_days lastday firstday tot_columns day freq num_freq x y   


clear file p l
display('Done.') 