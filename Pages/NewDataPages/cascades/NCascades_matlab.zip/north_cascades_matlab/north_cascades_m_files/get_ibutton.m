   %getibutton.m Assembled by Natalie Low 8/08/08
   %reads in ibutton data into matlab the following format: 
              %(1,:) 4-digit year, GMT
              %(2,:) 2-digit month GMT
              %(3,:) 2-digit day GMT
              %(4,:) 2-digit hour GMT
              %(5,:) 2-digit minute GMT
              %(6,:) julian date format GMT
              %(7,:) year-day format GMT
              %(8,:) temperature in degrees celsius
              %(9,:) local date (serialdate format) used for calculating
                    %daily mean, min, max, etc... (PST)
              %(10,:) julian date format PST
   %number of textfiles
   d = [45]%[33 34 35 36 37 38 39 40 41 42 43 44]; %[33 34 35 36 37 38 39 40 41 42 43 44] %33 34 35 36 37 38 39 40 41 42 43 44]%   %[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30];   %
   
  for i=1:length(d)
      
      display(['Processing instrument ' num2str(d(i)) ' (' num2str(i) '/' num2str(length(d)) ')...']) % Display progress
    %enter the location of the text files here
      eval(['location=''C:\Documents and Settings\Grad\My Documents\North_Cascades\ibutton_data_nameformatted\' num2str(d(i)) '.txt'';'])
  
   [date,c,Temp]=textread(location, '%s %s %f', 'delimiter',',');  %allocate raw data
   [sdate,time,AMPM]= textread(location, '%s %s %s', 'delimiter',' ');   %allocate raw data
   
   date=char(date);
   sdate=char(sdate);
   
   serialdate = datenum(date, 'mm/dd/yy HH:MM:SS PM');
   serialdate = serialdate';
   
   serialdate_shrt = datenum(sdate, 'mm/dd/yy'); %the short serial date
   gmt_hr = str2num(datestr(serialdate, 'HH'));  %the hour in gmt
   serial_rows = length(serialdate_shrt(:,1));
   
   temp(1,:) = str2num(datestr(serialdate, 'yyyy')); % 4-digit year
   temp(2,:) = str2num(datestr(serialdate, 'mm'));  % 2-digit month
   temp(3,:) = str2num(datestr(serialdate, 'dd'));  % 2-digit day
   temp(4,:) = str2num(datestr(serialdate, 'HH'));  % 2-digit hour
   temp(5,:) = str2num(datestr(serialdate, 'MM'));  % 2-digit minute
   
   jday_gmt = julday(temp(1,:),temp(2,:),temp(3,:),temp(4,:),temp(5,:));
   jday_pst = julday(temp(1,:),temp(2,:),temp(3,:),temp(4,:),temp(5,:));
   
   for j=1:serial_rows %makes hrs 0-7 gmt continue to be the same day pst in both serialdate format and julian day
       if gmt_hr(j,1) < 8
           serialdate_shrt(j) = serialdate_shrt(j) - 1;
           jday_pst(j) = floor(jday_pst(j));
       else
           serialdate_shrt(j) = serialdate_shrt(j);
           jday_pst(j) = floor(jday_pst(j)) + 1;
       end
       if jday_pst(j) == 0; %this eliminates day 366 %for a leap yr this should be changed to 367
           jday_pst(j) = 365;  
       end
   end
   
   serialdate_shrt = serialdate_shrt';
   
   
   temp(6,:)= jday_gmt;   % julian date format in GMT
   temp(7,:)=temp(1,:)+temp(6,:)/365; %year-day format
   temp(8,:)=Temp';  %temperature in degrees celsius
   temp(9,:)=serialdate_shrt;   %reports the local date (serialdate format) used for calculating daily mean, min, max, etc.
   temp(10,:) = jday_pst;   %julian date format in PST
   
   eval([ 'ibut' num2str(d(i)) '=temp(1:10,:);'])  %create variable containing formatted data
   
   clear  jday_gmt jday_pst serialdate j serialdate_shrt gmt_hr serial_rows date ignore c sdate location serialtime temp time Temp AMPM
   
  end
    
   clear d i 
   display('Done.')       