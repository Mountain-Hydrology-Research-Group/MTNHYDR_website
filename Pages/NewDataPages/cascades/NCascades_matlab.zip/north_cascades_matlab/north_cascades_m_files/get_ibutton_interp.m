%This program is to be used after importing data into matlab using 
%get_ibutton.m  If any NaNs exist for the temperature data, they must be 
%replaced with -999.

%This program will interpolate temperature data into a common 
%format which reports the temperature every hour on the hour

%After running this program you will have a new file entitled 'ibuttons'
%You can then type something like "dlmwrite('NorthCascades_ibuttons',ibuttons)"
%into the command prompt to create a .csv file

%Enter the ibutton sensor numbers here:
d = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 33 34 35 36 37 38 39 40 41 42 43 44 45]; %[5 17 18 19 20 23 24 39 40 41 68 69 70]; %[1 2 32 34 37 39 40 50 7 9 10 203 33 36 38 4 5 60 8 333];


%The dates in which all the data overlap must first be established

for i = 1
    file = eval(['ibut' num2str(d(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    T_firstday = file(9,1);
    T_lastday = file(9,end);
end

clear i file

for i=1:length(d)
    
    file = eval(['ibut' num2str(d(i));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    firstday = file(9,1);
    lastday = file(9,end);
    
    if firstday >= T_firstday
        T_firstday = firstday;
    end
    
    if lastday <= T_lastday
        T_lastday = lastday;
    end
end

clear firstday lastday i file

%Now we can create a new time series for every hour on the hour
%using T_firstday and T_lastday

tot_days = T_lastday - T_firstday + 1;  %tells you the total number of days in the file
tot_hrs = 24 * tot_days;
dy = T_firstday;
l = 1;

for k = 1:tot_hrs
        if l == 24 
            time_int(k) =  dy + ((l-1)* (0.01));
            dy = dy + 1;
            l = l - 23;

        elseif l >= 2 && l <= 23
            time_int(k) =  dy + ((l-1)* (0.01));
            l = l + 1;
        else
            time_int(k) =  dy;  %set the new time interval to every hour
            l = l + 1;
        end
end

clear k l

%Next format the date in PST as: serialdate.time where time is expressed as
%decimal_hour/100  ex. if the time were 23:48  this would be 
%(23 + 48/60)/100

for i = 1:length(d)
    file = eval(['ibut' num2str(d(i));]);
    
    first = find(file(9,:) == T_firstday,1, 'first');
    last = find(file(9,:) == T_lastday,1, 'last');
    long = last - first + 1;
    k = first;

    for j = 1:long
       hour = (file(4,k)) + (file(5,k)/60);
       if hour >= 8
            hour = (hour - 8) / 100;
       else
           hour = (hour + 16) / 100;
       end
       %hr(j) = hour;
       day(j) = file(9,k) + hour;
       if j ~= long
           k = k + 1;
       end
    end
   
    new_temp = interp1(day,file(8,first:last),time_int);
    temp(i+4,:) = new_temp;
    clear day
    
end

serialdate = floor(time_int);
new_hour = (time_int - serialdate) * 100;

temp(1,:) = str2num(datestr(serialdate, 'yyyy')); % 4-digit year
temp(2,:) = str2num(datestr(serialdate, 'mm'));  % 2-digit month
temp(3,:) = str2num(datestr(serialdate, 'dd'));  % 2-digit day
temp(4,:) = roundn(new_hour, 0);  % 2-digit hour
eval(['ibuttons' ' = temp(1:i+4,:);'])  %create variable containing formatted data
  
display('Done')
clear d i j k last long new_hour new_temp serialdate temp time_int tot_days tot_hrs T_firstday T_lastday dy file first hour
   