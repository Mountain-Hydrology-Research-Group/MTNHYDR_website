function dtg = julday4(yr, mo, da, hr, minu)
%JULDAY2         Conversion from yrmoda to julian day.
%
%               JULDAY2(yr,mo,da, hr, min) returns the julian day of the inputted yr
%                       in the format julianday.
%
%       Example:
%               JULDAY(94,5,22) returns (142,94).
%
%       Jason Frankson, January 1994
%       modified by Jessica july 2000 to include hour and minute
%                           and to not show the year
%       modified Jan 31, 2003 to cycle through years if more than one
%       because need to check each for leap year
%   jday3 is modified 5/29/03 to shift dtg back so that noon on jan first
%   is 0.5 and not 1.5 -- this is for consistency with Dave and Rich and
%   Larry's datasets.
%julday3 will change days to days', julday4 will not!
if (mo > 12)
        mo = mo - 12;
        yr = yr + 1;
end;

for yri=min(yr):max(yr)
cumd=[0,31,59,90,120,151,181,212,243,273,304,334];
if (rem(yri,400)==0) inc=1;
elseif ((rem(yri,100)~=0)&(rem(yri,4)==0)) inc=1;
else inc=0;
end
cumd(3:12)=cumd(3:12)+inc;
yrkp=find(yr==yri);
days(yrkp)= reshape(cumd(mo(yrkp)),size(da(yrkp)))+da(yrkp);
end

%days=days';
minu=minu/60;
hr = hr+minu;
hr = hr/24;
days = days+hr;

%dtg=[days,yr];
dtg=days-1;
