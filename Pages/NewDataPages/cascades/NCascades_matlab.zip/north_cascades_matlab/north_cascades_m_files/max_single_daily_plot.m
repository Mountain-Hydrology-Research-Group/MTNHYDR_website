%max_single_daily_plot.m creates a simple plot of the daily
%max temperature for a particular sensor across a data set

%Must first read ibutton data in using the method get_ibutton.m

%Created by Natalie Low.


function single_daily_max_plot(file)  %pass it the name of the file you wish to analyze

    lastday = file(9,end);%this finds the last day in the file (serial date formatted)
    firstday = file(9,1);  %this finds the first day in the file (serial date formatted)

    tot_columns = length(file(9,:));
    tot_days = lastday - firstday + 1;  %tells you the total number of days in the file

    day = firstday;
    y = 0;
    x = y + 1;

    for i = 1:tot_columns
        if i == x
            for j = 1:tot_days
                if day <= lastday
                    freq = find(file(9,:)==day);
                    num_freq = length(freq);
                    x = y + 1;
                    y = x - 1 + num_freq;

                    m(j) = max(file(8,x:y));
                    jd(j) = mean(file(10,x:y));
                    d(j) = day;
                    day = day + 1;
                end  
            end    
        end  
    end

    yr = str2num(datestr(d, 'yyyy'));

    for k = 1:tot_days
        if yr(k,1)==2008    %2008 was a leap yr. if no leap yr-- comment out
                    jyr_dy(k) = yr(k,1) + jd(1,k)/366;
                else 
                    jyr_dy(k) = yr(k,1) + jd(1,k)/365;
        end
    end

    plot(jyr_dy, m,'r');
   
    clear file p l d k file jd jyr_dy yr m j i tot_days lastday firstday tot_columns day old_num_freq freq num_freq x y   
