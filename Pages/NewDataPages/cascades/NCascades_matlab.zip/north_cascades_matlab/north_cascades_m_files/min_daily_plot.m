%min_daily_plot.m creates a plot with multiple subplots.  Each sub-plot
%shows the daily min temperature over the length of the data set
%for a particular sensor.

%Since each sensor to be plotted creates a sub-plot, this program
%is not desireable for plotting more than 5-10 sensors.

%This method is to be used on data that has been read in using the method
%get_ibutton.m

%Created by Natalie Low.

%Enter which sensors you would like plotted:
p = [1]; % 33 34 35 36 37 38 39 40 41 42 43 44] %33 34 35 36 37 38 39 40 41 42 43 44]%   %[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30];   %

for l=1:length(p)
        
    file = eval(['ibut' num2str(p(l));]); %enter the filename prefix just in front of num2str(p(l))  ex. file = eval(['prefix' num2str(p(l));]);
    
    lastday = file(9,end);  %this finds the last day in the file (serial date formatted)
    firstday = file(9,1);  %this finds the first day in the file (serial date formatted)

    tot_columns = length(file(9,:));
    tot_days = lastday - firstday + 1;  %tells you the total number of days in the file

    day = firstday;
    y = 0;
    x = y + 1;

    for i = 1:tot_columns
        if i == x
            for j = 1:tot_days
                if day <= lastday
                    freq = find(file(9,:)==day);
                    num_freq = length(freq);
                    x = y + 1;
                    y = x - 1 + num_freq;

                    m(j) = min(file(8,x:y));
                    jd(j) = mean(file(10,x:y));
                    d(j) = day;
                    day = day + 1;
                end  
            end    
        end  
    end

    yr = str2num(datestr(d, 'yyyy'));

    for k = 1:tot_days
        if yr(k,1)==2008    %2008 was a leap yr. if no leap yr-- comment out
                    jyr_dy(k) = yr(k,1) + jd(1,k)/366;
                else 
                    jyr_dy(k) = yr(k,1) + jd(1,k)/365;
        end
    end

    plot(jyr_dy, m,'g');
    hold on
    
    clear d k file jd jyr_dy yr m j i tot_days lastday firstday tot_columns day old_num_freq freq num_freq x y   
end

clear p l
display('Done.') 