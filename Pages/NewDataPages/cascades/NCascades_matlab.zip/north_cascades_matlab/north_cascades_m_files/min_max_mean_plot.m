%This method simply creates a figure containing 
%a singele plot containing sub-plots of each the daily min, max, and mean
%for a given ibutton file (use get_ibutton.m to properly 
%format the ibutton data).  This method calls the three
%other methods: mean_single_daily_plot(file),
%max_single_daily_plot(file), and min_single_daily_plot(file)

%Created and last edited by Natalie Low 09/20/08

function min_max_mean_plot(file)

figure;
title('title')

subplot(3,1,1)
mean_single_daily_plot(file)
ylabel(['Temp. in ' setstr(176) 'C'])
title('Daily Mean Temperature')

subplot(3,1,2)
min_single_daily_plot(file)
ylabel(['Temp. in ' setstr(176) 'C'])
title('Daily Minimum Temperature')

subplot(3,1,3)
max_single_daily_plot(file)
ylabel(['Temp. in ' setstr(176) 'C'])
title('Daily Maximum Temperature')