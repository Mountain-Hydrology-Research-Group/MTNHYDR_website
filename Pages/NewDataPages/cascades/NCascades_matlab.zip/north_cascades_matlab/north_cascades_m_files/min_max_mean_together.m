%This method simply creates a figure containing 
%the daily min, max, and mean for 
%a given ibutton file (use get_ibutton.m to properly 
%format the ibutton data)
%This method calls the following three other methods: 
%mean_single_daily_plot(),
%min_single_daily_plot(), and max_single_daily_plot()

%Created and last edited by Natalie Low 08/21/08

%function together_min_max_mean(file,sensor_num) %pass this method the filename for file and the ibutton sensor number for sensor_num
d = [41 42 43 44];  %enter the number of ibuttons that you would like to plot

location1 = 'Thunder Creek at Elev. 364m';
location2 = 'Thunder Creek at Elev. 1073m';
location3 = 'Thunder Creek at Elev. 970m';
location4 = 'Thunder Creek at Elev. 745m';
location5 = 'Thunder Creek at Elev. 703m';
location6 = 'Thunder Creek at Elev. 721m';
location7 = 'Maple Pass at Elev. 1729m';
location8 = 'Maple Pass at Elev. 1672m';
location9 = 'Maple Pass at Elev. 1843m';
location10 = 'Maple Pass at Elev. 2024m';
location11 = 'Maple Pass at Elev. 2121m';
location12 = 'Happy Creek Nature Trail Elev. 663m';
location13 = 'Canyon Creek Trailhead Elev. 593m';
location14 = 'East Creek Trailhead Elev. 797m';
location15 = 'Easy Pass Trailhead Elev. 1133m';
location16 = 'Bridge Creek Trailhead Elev. 1390m';
location17 = 'Blue Lake Trailhead 1640m';
location18 = 'Lone Fir Campground Elev. 1167m';
location19 = 'Cedar Creek Trail Elev. 697m';
location20 = 'Turnout west of Early Winter Elev. 695m';
location21 = 'Cutthroat Creek Elev. 1222m';
location22 = 'Raining Pass Trailhead Elev. 1516m';

for i = 1:length(d)
    figure;
    file = eval(['ibut' num2str(d(i))]);  %enter the prefix of your ibutton date filenames; ie.  for filename ibut43 the prefix is 'ibut'
    
    mean_single_daily_plot(file)
    hold on
    min_single_daily_plot(file)
    max_single_daily_plot(file)
    ylabel(['Temperature in ' setstr(176) 'C'])
    legend('Daily Mean','Daily Minimum', 'Daily Maximum','Location','Best')
    
    j = d(1,i)
    even_or_odd = (rem(j,2))  %returns 0 for even, 1 for odd

    if  even_or_odd == 0
        j = j/2 
    else
        j = (j + 1)/2 
    end
    location = eval(['location' num2str(j)])
    title(['Temperature Data for ' location])
    hold off
end

display('Done')