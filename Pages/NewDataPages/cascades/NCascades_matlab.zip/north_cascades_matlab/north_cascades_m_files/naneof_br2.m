% NANEOF_BR2.M
% Function to compute EOFs from demeaned data with NaNs:
% function [B,vars,amps]=naneof(d);
% Computes EOFs of ROW DIMENSION in d matrix
% d[MxN], B[MxM] EOFs are in columns, vars[Mx1], amps[NxM] amplitudes
% are in columns (new!)
% EOFs are orthonormal
% variances are in % of total variance ( sum(d(:).^2)/N, not /M/N!)

% following method of Becken and Rixen, JTECH 2003 v20 1839-
%version 2 tries to eliminate column thing
function [B,vars,amps]=naneof_br2(X);


% the data should be de-meaned by now
X0 = X;
idok = find(~isnan(X));

% id_val = idok(floor( rand(floor(length(idok)/50),1)*length(idok) ));% validation subset
% X_val = X(id_val);
% mx_val = sum(column(X_val).^2);
% % remove validation subset from the data
% X(id_val) = nan;
% idok = find(~isnan(X));


% replace NaNs by zeros
X(isnan(X)) = 0;



Nit = 100;
tol = 1e-5;
% find out how many eigenfunctions to retain...
dxex = zeros(Nit,10);
% X1 = X;
% for Ne=1:20
Ne = 6;
X1 = X;
    for k=2:Nit
        % compute SVD
        [U,D,V] = svd(X1);
        % truncate and estimate "interpolated" D
        %SVD    Singular value decomposition.
%   [U,S,V] = SVD(X) produces a diagonal matrix S, of the same 
%   dimension as X and with nonnegative diagonal elements in
%   decreasing order, and unitary matrices U and V so that
%   X = U*S*V'.
%
%   S = SVD(X) returns a vector containing the singular values.
%
%   [U,S,V] = SVD(X,0) produces the "economy size"
%   decomposition. If X is m-by-n with m > n, then only the
%   first n columns of U are computed and S is n-by-n.
%   For m <= n, SVD(X,0) is equivalent to SVD(X).
%
%   [U,S,V] = SVD(X,'econ') also produces the "economy size"
%   decomposition. If X is m-by-n with m >= n, then it is
%   equivalent to SVD(X,0). For m < n, only the first m columns 
%   of V are computed and S is m-by-m.
%

        N = Ne;
        % truncate
        Ut = U(:,1:N);
        Dt = D(1:N,1:N);
        Vt = V(:,1:N);
        Xa = Ut*Dt*Vt';
        Xa(idok) = X(idok); % restore real data
        X2 = Xa;

        % termination criterium?
        dx=sum((X2-X1).^2,1); %dx = sum(column(X2-X1).^2);
        mx=sum(X2.^2,1); %mx = sum(column(X2.^2));
        dxex = dx/mx;
        if dxex <tol,
            fprintf('Converged in %d iterations to the tolerance of %.0e\n',k-1,tol);
            break
        end
        
        X1 = X2;
    end
    % error?
%     Xa = Ut*Dt*Vt';
%     dx_val = sum(column(Xa(id_val)-X_val).^2);
% 
%     err(Ne) = dx_val/mx_val;
% end
% plot(err,'g.-');
% ylabel('Error');
% xlabel('EOFs retained');
% keyboard

% units in B
B = U*D;  %the temporal modes
amps = V; % the spatial modes
% % units in amp
% B = U;
% amps = V*D';

%vars = diag(D)/sum(diag(D))*100;
%total_var=nanmean(X(:).^2); %?
total_var=mean(X(:).^2); %the variance of the original temperature series
vars=diag(D).^2/total_var*100/prod(size(X0)); %divide by the product of the original matrix size and by the variance
