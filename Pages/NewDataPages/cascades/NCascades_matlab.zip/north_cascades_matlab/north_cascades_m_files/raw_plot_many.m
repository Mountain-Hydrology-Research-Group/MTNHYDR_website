%This function simply plots raw ibutton time vs. temp data
%All you need to do is pass it the file name and a title (ttl) for the plot

%If you want to plot the data from more or less than 6 sensors
%just change a few things
function raw_plot(file1, file2, file3, file4, file5, file6, ttl)

color = ['y' 'g' 'r' 'b' 'm' 'c'];
leg_ttl = ['Elev. 364' 'Elev. 1073' 'Elev. 970' 'Elev. 745' 'Elev. 703'  'Elev. 721'];  %must enter the title of each file for the legend


for i = 1:6
    file = eval(['file' num2str(i)]);
    plot(file(7,:),file(8,:), color(1,i))
hold on

end
ylabel(['Temperature in ' setstr(176) 'C'])
title(ttl)
legend(leg_ttl(1,1),leg_ttl(1,2),leg_ttl(1,3),leg_ttl(1,4),leg_ttl(1,5),leg_ttl(1,6), 'location', 'best')
hold off
end
