%This function simply plots raw ibutton time vs. temp data
%All you need to do is pass it the file name and a title (ttl) for the plot

function raw_plot(file, ttl)

plot(file(7,:), file(8,:),'y')
hold on
ylabel(['Temperature in ' setstr(176) 'C'])
title(ttl)

end
