%startup.m
%runs when matlab starts

set(0,'defaultaxeslinewidth',1)
set(0,'defaultaxesbox','on')
set(0,'defaulttextfontsize',16)
set(0,'defaultaxesfontsize',14)
set(0,'defaulttextfontangle','normal')
set(0,'defaultaxesfontangle','normal')
set(0,'defaultaxesfontweight','normal')
set(0,'defaultlinelinewidth',2)

%the syntax is:
%set(0,'default<object><property>',value)

path(path,'C:\Documents and Settings\Grad\My Documents\North_Cascades\Colorado_Tstuff\caitlin_matlab');
path(path,'C:\Documents and Settings\Grad\My Documents\North_Cascades\Colorado_Tstuff\Backup_catlin_matlab');
path(path,'C:\Documents and Settings\Grad\My Documents\North_Cascades\north_cascades_matlab\north_cascades_m_files');
path(path,'C:\Documents and Settings\Grad\My Documents\North_Cascades\north_cascades_matlab\north_cascades_mat_files');
path(path,'C:\Documents and Settings\Grad\My Documents\North_Cascades\north_cascades_matlab\Jessica_m_files');
path(path,'C:\Documents and Settings\Grad\My Documents\Natalie_Yosemite_Data\matlab_programs');
path(path,'C:\Documents and Settings\Grad\My Documents\Natalie_Yosemite_Data\Old_Data\mfiles');
path(path,'C:\Documents and Settings\Grad\My Documents\North_Cascades\north_cascades_matlab\north_cascades_m_files\nansuite\nansuite');
path(path,'C:\Documents and Settings\Grad\My Documents\MtRainier\Matlab\M_Files');
